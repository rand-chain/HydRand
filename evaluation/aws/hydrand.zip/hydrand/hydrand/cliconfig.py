# set to True in __main__
# do not modify
# used to detect that cli-arguments should be parsed in config.py

USE_CLI_CONFIG = False
